set -e
cd "$(dirname "$0")"
: "${JNI_INC:?set JNI_INC to the directory that contains jni.h and linux/jni_md.h}"
OUT=out
rm -rf $OUT
mkdir -p $OUT/inc $OUT/stubs $OUT/pkg
cp "$JNI_INC/jni.h" $OUT/inc/jni.h
cp "$JNI_INC/linux/jni_md.h" $OUT/inc/jni_md.h
sed -i 's|#include <stdio.h>|typedef struct __sFILE FILE;|' $OUT/inc/jni.h
T="--target=aarch64-linux-android21"
for l in c log dl; do
  clang $T -shared -nostdlib -fuse-ld=lld -fPIC -Wl,-soname,lib$l.so -o $OUT/stubs/lib$l.so stubs/lib$l.c
done
clang++ $T -std=c++17 -O2 -fPIC -fno-exceptions -fno-rtti -fno-threadsafe-statics -fno-stack-protector -ffreestanding -nostdinc++ -Wall -Wno-unused-parameter -I $OUT/inc -I src -c src/skinchanger.cpp -o $OUT/skinchanger.o
clang++ $T -shared -nostdlib -fuse-ld=lld -s -Wl,--version-script=exports.map -Wl,-z,max-page-size=16384 -Wl,--build-id=none -Wl,--hash-style=both -Wl,-soname,libskinchanger.so -o $OUT/libskinchanger.so $OUT/skinchanger.o -L $OUT/stubs -lc -ldl -llog
cp -r module/. $OUT/pkg/
mkdir -p $OUT/pkg/zygisk
cp $OUT/libskinchanger.so $OUT/pkg/zygisk/arm64-v8a.so
(cd $OUT/pkg && zip -q -r -X ../Standoff2_SkinChanger_v1.2.zip META-INF module.prop customize.sh zygisk)
