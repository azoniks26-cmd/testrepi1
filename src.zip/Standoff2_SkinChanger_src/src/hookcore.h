#pragma once
#include <stdint.h>

static inline bool hk_is_adrp(uint32_t i) {
    return (i & 0x9F000000u) == 0x90000000u;
}

static inline bool hk_is_pcrel(uint32_t i) {
    if ((i & 0x1F000000u) == 0x10000000u) return true;
    if ((i & 0x3B000000u) == 0x18000000u) return true;
    if ((i & 0x7C000000u) == 0x14000000u) return true;
    if ((i & 0xFF000010u) == 0x54000000u) return true;
    if ((i & 0x7E000000u) == 0x34000000u) return true;
    if ((i & 0x7E000000u) == 0x36000000u) return true;
    return false;
}

static inline int hk_build_tramp(uint32_t *out, const uint32_t *in, uint64_t pc, uint64_t ret) {
    int n = 0;
    for (int k = 0; k < 4; k++) {
        uint32_t ins = in[k];
        uint64_t ipc = pc + 4u * (uint32_t) k;
        if (hk_is_adrp(ins)) {
            uint32_t rd = ins & 31u;
            int64_t imm = (int64_t) ((((ins >> 5) & 0x7FFFFu) << 2) | ((ins >> 29) & 3u));
            if (imm & (1 << 20)) imm -= (1 << 21);
            uint64_t val = ((ipc >> 12) + (uint64_t) imm) << 12;
            out[n++] = 0x58000040u | rd;
            out[n++] = 0x14000003u;
            out[n++] = (uint32_t) val;
            out[n++] = (uint32_t) (val >> 32);
        } else if (hk_is_pcrel(ins)) {
            return -1;
        } else {
            out[n++] = ins;
        }
    }
    out[n++] = 0x58000050u;
    out[n++] = 0xD61F0200u;
    out[n++] = (uint32_t) ret;
    out[n++] = (uint32_t) (ret >> 32);
    return n;
}

static inline void hk_build_patch(uint32_t *out, uint64_t hook) {
    out[0] = 0x58000050u;
    out[1] = 0xD61F0200u;
    out[2] = (uint32_t) hook;
    out[3] = (uint32_t) (hook >> 32);
}
