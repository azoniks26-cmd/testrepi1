#include <stddef.h>
#include <stdint.h>
#include <jni.h>
typedef unsigned long dev_t;
typedef unsigned long ino_t;
#include "zygisk.hpp"
#include "hookcore.h"

extern "C" {
int __android_log_print(int prio, const char *tag, const char *fmt, ...);
int open(const char *path, int flags, ...);
int close(int fd);
long read(int fd, void *buf, size_t n);
long write(int fd, const void *buf, size_t n);
int pipe(int fds[2]);
void *mmap(void *addr, size_t len, int prot, int flags, int fd, long off);
int mprotect(void *addr, size_t len, int prot);
int getpagesize(void);
int pthread_create(unsigned long *t, const void *attr, void *(*fn)(void *), void *arg);
int pthread_detach(unsigned long t);
int usleep(unsigned int us);
struct PhdrInfo {
    uint64_t addr;
    const char *name;
    const void *phdr;
    uint16_t phnum;
};
int dl_iterate_phdr(int (*cb)(PhdrInfo *, size_t, void *), void *data);
}

namespace {

constexpr uint64_t RVA_FSNE = 0xA028F7C;
constexpr uint64_t RVA_NJTD = 0xA037F9C;
// WeaponIds.Knife raw value = 0x46 (70). NOTE: 0x1E in dump.cs is the static-field *offset*, not the value
// (verified in WeaponIds..cctor @ RVA 0x9733B5C: mov w1,#0x46 -> stored at static offset 0x1E).
constexpr uint8_t ID_KNIFE = 0x46;
constexpr int32_t SKIN_M9_DRAGON_GLASS = 71005;
constexpr int32_t SKIN_GLOVES_DRAGON_GLASS = 3032;

const uint32_t SIG_FSNE[4] = {0xD10183FFu, 0xA9016FFEu, 0xA90267FAu, 0xA9035FF8u};
const uint32_t SIG_NJTD[4] = {0xA9BE57FEu, 0xA9014FF4u, 0xD0012AD5u, 0x2A0103F3u};

JavaVM *g_vm = nullptr;
const char *g_msg = nullptr;

void *(*orig_fsne)(void *, uint64_t, int32_t, void *) = nullptr;
void *(*orig_njtd)(void *, int32_t, void *) = nullptr;

void *hk_fsne(void *self, uint64_t wid, int32_t skin, void *mi) {
    if ((wid & 0xFFu) == ID_KNIFE && skin == 0) skin = SKIN_M9_DRAGON_GLASS;
    return orig_fsne(self, wid, skin, mi);
}

void *hk_njtd(void *self, int32_t id, void *mi) {
    if (id == 0) id = SKIN_GLOVES_DRAGON_GLASS;
    return orig_njtd(self, id, mi);
}

bool streq(const char *a, const char *b) {
    while (*a && *a == *b) {
        a++;
        b++;
    }
    return *a == *b;
}

bool endswith(const char *s, const char *suf) {
    size_t n = 0, m = 0;
    while (s[n]) n++;
    while (suf[m]) m++;
    if (m > n) return false;
    return streq(s + (n - m), suf);
}

int g_pipe[2] = {-1, -1};
bool g_pipe_ready = false;

bool safe_read(uintptr_t addr, void *buf, size_t n) {
    if (!g_pipe_ready) {
        g_pipe_ready = true;
        if (pipe(g_pipe) != 0) g_pipe[0] = g_pipe[1] = -1;
    }
    if (g_pipe[0] < 0) return false;
    long w = write(g_pipe[1], (const void *) addr, n);
    if (w != (long) n) return false;
    long r = read(g_pipe[0], buf, n);
    return r == (long) n;
}

void sleep_ms(int ms) {
    while (ms > 0) {
        int step = ms > 100 ? 100 : ms;
        usleep((unsigned int) step * 1000u);
        ms -= step;
    }
}

void flush_cache(void *start, size_t len) {
    uint64_t ctr;
    asm volatile("mrs %0, ctr_el0" : "=r"(ctr));
    uintptr_t dl = 4u << ((ctr >> 16) & 0xF);
    uintptr_t il = 4u << (ctr & 0xF);
    uintptr_t s = (uintptr_t) start;
    uintptr_t e = s + len;
    for (uintptr_t a = s & ~(dl - 1); a < e; a += dl) asm volatile("dc cvau, %0" ::"r"(a) : "memory");
    asm volatile("dsb ish" ::: "memory");
    for (uintptr_t a = s & ~(il - 1); a < e; a += il) asm volatile("ic ivau, %0" ::"r"(a) : "memory");
    asm volatile("dsb ish\n\tisb" ::: "memory");
}

int find_cb(PhdrInfo *info, size_t, void *data) {
    if (info->name && endswith(info->name, "libunity.so")) {
        *(uintptr_t *) data = (uintptr_t) info->addr;
        return 1;
    }
    return 0;
}

uintptr_t find_unity() {
    uintptr_t base = 0;
    dl_iterate_phdr(find_cb, &base);
    return base;
}

bool matches(uintptr_t addr, const uint32_t *sig) {
    uint32_t cur[4];
    if (!safe_read(addr, cur, sizeof(cur))) return false;
    for (int i = 0; i < 4; i++)
        if (cur[i] != sig[i]) return false;
    return true;
}

bool install_hook(uintptr_t target, const uint32_t *sig, void *hook, void **orig) {
    uint32_t tramp[16];
    int n = hk_build_tramp(tramp, sig, target, target + 16);
    if (n < 0) return false;
    void *mem = mmap(nullptr, 4096, 3, 0x22, -1, 0);
    if (mem == (void *) -1) return false;
    uint32_t *t = (uint32_t *) mem;
    for (int i = 0; i < n; i++) t[i] = tramp[i];
    if (mprotect(mem, 4096, 5) != 0) return false;
    flush_cache(mem, (size_t) n * 4);
    *orig = mem;

    uint32_t patch[4];
    hk_build_patch(patch, (uint64_t) hook);
    uintptr_t ps = (uintptr_t) getpagesize();
    uintptr_t page = target & ~(ps - 1);
    size_t span = (target + 16 > page + ps) ? ps * 2 : ps;
    if (mprotect((void *) page, span, 7) != 0) return false;
    uint32_t *dst = (uint32_t *) target;
    for (int i = 0; i < 4; i++) dst[i] = patch[i];
    mprotect((void *) page, span, 5);
    flush_cache((void *) target, 16);
    return true;
}

struct ToastCtx {
    JavaVM *vm;
    jobject toast;
    jobject looper;
};

ToastCtx g_toast;

void clear_exc(JNIEnv *env) {
    if (env->ExceptionCheck()) env->ExceptionClear();
}

void *canceller(void *) {
    sleep_ms(3000);
    JNIEnv *env = nullptr;
    if (g_toast.vm->AttachCurrentThread((void **) &env, nullptr) != JNI_OK) return nullptr;
    jclass tc = env->FindClass("android/widget/Toast");
    if (tc) {
        jmethodID cancel = env->GetMethodID(tc, "cancel", "()V");
        if (cancel) env->CallVoidMethod(g_toast.toast, cancel);
    }
    clear_exc(env);
    jclass lc = env->FindClass("android/os/Looper");
    if (lc) {
        jmethodID quit = env->GetMethodID(lc, "quit", "()V");
        if (quit) env->CallVoidMethod(g_toast.looper, quit);
    }
    clear_exc(env);
    env->DeleteGlobalRef(g_toast.toast);
    env->DeleteGlobalRef(g_toast.looper);
    g_toast.vm->DetachCurrentThread();
    return nullptr;
}

void *toast_thread(void *) {
    JNIEnv *env = nullptr;
    if (!g_vm || g_vm->AttachCurrentThread((void **) &env, nullptr) != JNI_OK) return nullptr;

    jclass at = env->FindClass("android/app/ActivityThread");
    clear_exc(env);
    if (!at) {
        g_vm->DetachCurrentThread();
        return nullptr;
    }
    jmethodID cur = env->GetStaticMethodID(at, "currentApplication", "()Landroid/app/Application;");
    clear_exc(env);
    jobject app = nullptr;
    for (int i = 0; i < 240 && cur; i++) {
        app = env->CallStaticObjectMethod(at, cur);
        clear_exc(env);
        if (app) break;
        sleep_ms(250);
    }
    if (!app) {
        g_vm->DetachCurrentThread();
        return nullptr;
    }
    sleep_ms(2000);

    jclass lc = env->FindClass("android/os/Looper");
    jmethodID prep = env->GetStaticMethodID(lc, "prepare", "()V");
    jmethodID my = env->GetStaticMethodID(lc, "myLooper", "()Landroid/os/Looper;");
    jmethodID loop = env->GetStaticMethodID(lc, "loop", "()V");
    clear_exc(env);
    env->CallStaticVoidMethod(lc, prep);
    clear_exc(env);
    jobject lp = env->CallStaticObjectMethod(lc, my);
    clear_exc(env);

    jclass tc = env->FindClass("android/widget/Toast");
    jmethodID mk = env->GetStaticMethodID(tc, "makeText",
                                          "(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;");
    jmethodID show = env->GetMethodID(tc, "show", "()V");
    clear_exc(env);
    jstring js = env->NewStringUTF(g_msg);
    jobject t = env->CallStaticObjectMethod(tc, mk, app, js, (jint) 1);
    clear_exc(env);
    if (!t || !lp) {
        g_vm->DetachCurrentThread();
        return nullptr;
    }
    env->CallVoidMethod(t, show);
    clear_exc(env);

    g_toast.vm = g_vm;
    g_toast.toast = env->NewGlobalRef(t);
    g_toast.looper = env->NewGlobalRef(lp);
    unsigned long tid;
    if (pthread_create(&tid, nullptr, canceller, nullptr) == 0) pthread_detach(tid);

    env->CallStaticVoidMethod(lc, loop);
    clear_exc(env);
    g_vm->DetachCurrentThread();
    return nullptr;
}

void start_toast(const char *msg) {
    g_msg = msg;
    unsigned long tid;
    if (pthread_create(&tid, nullptr, toast_thread, nullptr) == 0) pthread_detach(tid);
}

void *worker(void *) {
    bool ok = false;
    int seen = 0;
    for (int i = 0; i < 2400; i++) {
        uintptr_t base = find_unity();
        if (base) {
            uintptr_t a = base + RVA_FSNE;
            uintptr_t b = base + RVA_NJTD;
            if (matches(a, SIG_FSNE) && matches(b, SIG_NJTD)) {
                bool r1 = install_hook(a, SIG_FSNE, (void *) hk_fsne, (void **) &orig_fsne);
                bool r2 = install_hook(b, SIG_NJTD, (void *) hk_njtd, (void **) &orig_njtd);
                __android_log_print(4, "AdxSkin", "hooks fsne=%d njtd=%d base=%p", (int) r1, (int) r2, (void *) base);
                ok = r1 && r2;
                break;
            }
            if (++seen > 200) break;
        }
        sleep_ms(50);
    }
    if (!ok) __android_log_print(6, "AdxSkin", "hook install failed");
    start_toast(ok ? "Modded by Adx" : "Modded by Adx (unsupported game version)");
    return nullptr;
}

}

class SkinChanger : public zygisk::ModuleBase {
public:
    void onLoad(zygisk::Api *a, JNIEnv *e) override {
        api = a;
        env = e;
    }

    void preAppSpecialize(zygisk::AppSpecializeArgs *args) override {
        target = false;
        if (args && args->nice_name) {
            const char *n = env->GetStringUTFChars(args->nice_name, nullptr);
            if (n) {
                target = streq(n, "com.axlebolt.standoff2");
                env->ReleaseStringUTFChars(args->nice_name, n);
            }
        }
        if (!target) api->setOption(zygisk::DLCLOSE_MODULE_LIBRARY);
    }

    void postAppSpecialize(const zygisk::AppSpecializeArgs *) override {
        if (!target) return;
        env->GetJavaVM(&g_vm);
        unsigned long tid;
        if (pthread_create(&tid, nullptr, worker, nullptr) == 0) pthread_detach(tid);
    }

private:
    zygisk::Api *api = nullptr;
    JNIEnv *env = nullptr;
    bool target = false;
};

REGISTER_ZYGISK_MODULE(SkinChanger)
