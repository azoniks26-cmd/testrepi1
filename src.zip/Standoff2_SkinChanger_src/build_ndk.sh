set -e
cd "$(dirname "$0")"
: "${ANDROID_NDK_HOME:?set ANDROID_NDK_HOME}"
BIN="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/linux-x86_64/bin"
OUT=out
rm -rf $OUT
mkdir -p $OUT/pkg
"$BIN/aarch64-linux-android21-clang++" -std=c++17 -O2 -fPIC -fno-exceptions -fno-rtti -fno-threadsafe-statics -fno-stack-protector -ffreestanding -nostdinc++ -Wall -Wno-unused-parameter -I src -c src/skinchanger.cpp -o $OUT/skinchanger.o
"$BIN/aarch64-linux-android21-clang++" -shared -nostdlib -fuse-ld=lld -s -Wl,--version-script=exports.map -Wl,-z,max-page-size=16384 -Wl,--build-id=none -Wl,--hash-style=both -Wl,-soname,libskinchanger.so -o $OUT/libskinchanger.so $OUT/skinchanger.o -lc -ldl -llog
cp -r module/. $OUT/pkg/
mkdir -p $OUT/pkg/zygisk
cp $OUT/libskinchanger.so $OUT/pkg/zygisk/arm64-v8a.so
(cd $OUT/pkg && zip -q -r -X ../Standoff2_SkinChanger_v1.2.zip META-INF module.prop customize.sh zygisk)
