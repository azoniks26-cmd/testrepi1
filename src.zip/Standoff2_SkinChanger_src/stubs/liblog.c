int __android_log_print(){return 0;}
