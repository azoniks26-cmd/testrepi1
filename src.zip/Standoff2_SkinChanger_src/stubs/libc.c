int open(){return 0;} int close(){return 0;} long read(){return 0;} long write(){return 0;} int pipe(){return 0;} void* mmap(){return 0;} int mprotect(){return 0;}
int getpagesize(){return 0;} int pthread_create(){return 0;} int pthread_detach(){return 0;} int usleep(){return 0;}
