SKIPUNZIP=0
if [ "$ARCH" != "arm64" ]; then
  abort "! Only arm64 devices are supported"
fi
ui_print "- Standoff 2 Skin Changer by Adx"
ui_print "- Target: com.axlebolt.standoff2"
ui_print "- Requires Zygisk enabled in Magisk"
ui_print "- Remove the game from DenyList"
set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/zygisk/arm64-v8a.so" 0 0 0644
